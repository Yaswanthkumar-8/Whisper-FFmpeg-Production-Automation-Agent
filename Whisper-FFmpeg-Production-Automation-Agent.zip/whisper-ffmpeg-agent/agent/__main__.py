"""
CLI entry for the Whisper + FFmpeg Production Automation Agent.

Usage (local):
    python -m agent process ./projects/example

Usage (Docker):
    docker compose run --rm agent process ./projects/example
"""
from __future__ import annotations

import logging
import sys

import click

from .pipeline.runner import ProductionAgent


logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s  %(message)s")


@click.group()
def cli() -> None:
    """Whisper + FFmpeg Production Automation Agent."""


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True))
@click.option("--auto-cuts", is_flag=True, help="Skip HITL and accept all cut suggestions.")
def process(project_dir: str, auto_cuts: bool) -> None:
    """Run the full production pipeline on a project directory."""
    click.echo(f"🎬  Processing project: {project_dir}")
    agent = ProductionAgent()

    hitl_fn = (lambda cuts: []) if auto_cuts else None
    run = agent.run(project_dir, human_review_fn=hitl_fn)

    if run.complete:
        render_output = run.outputs.get("render", {})
        click.echo(f"\n✅  Pipeline complete!")
        click.echo(f"    Output: {render_output.get('output_path')}")
        click.echo(f"    Size:   {render_output.get('size_mb')} MB")
    else:
        click.echo(f"\n❌  Pipeline halted at step: {run.failed_at}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    cli()
