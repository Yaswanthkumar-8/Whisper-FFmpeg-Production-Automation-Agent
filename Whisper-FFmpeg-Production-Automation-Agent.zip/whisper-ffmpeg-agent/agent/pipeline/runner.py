"""
Pipeline planner — uses OpenAI tool-use loop to chain production tools.
Per-step checkpoints halt the pipeline on bad output instead of burning a full render.
"""
from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import openai

from .tools import TOOLS
from .tools.implementations import (
    apply_cuts,
    burn_captions,
    color_grade,
    render,
    suggest_cuts,
    transcribe,
)

logger = logging.getLogger(__name__)

TOOL_DISPATCH = {
    "transcribe": transcribe,
    "suggest_cuts": suggest_cuts,
    "apply_cuts": apply_cuts,
    "burn_captions": burn_captions,
    "color_grade": color_grade,
    "render": render,
}

SYSTEM_PROMPT = """You are a video production automation agent. 
Given a project directory, orchestrate the full production pipeline:
  1. transcribe the raw video
  2. suggest_cuts for filler words and silence
  3. (HITL) apply_cuts after human review
  4. burn_captions from the transcript SRT
  5. color_grade the video
  6. render the final deliverable

Use tools step by step. After each tool call, check the result for errors before proceeding.
If a step fails, stop and report the error instead of continuing.
When suggest_cuts returns, always summarise the suggestions and wait for user confirmation before calling apply_cuts."""


@dataclass
class PipelineRun:
    project_dir: str
    outputs: dict[str, Any] = field(default_factory=dict)
    approved_cuts: list[dict[str, float]] | None = None
    failed_at: str | None = None
    complete: bool = False


class ProductionAgent:
    def __init__(self) -> None:
        self.client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])

    def run(self, project_dir: str, human_review_fn: Any = None) -> PipelineRun:
        """
        Run the production pipeline.
        human_review_fn: optional callable(suggestions) → list[keep_segments]
        If None, cut suggestions are printed and pipeline pauses.
        """
        project = Path(project_dir)
        video_files = list(project.glob("*.mp4")) + list(project.glob("*.mov")) + list(project.glob("*.mkv"))
        if not video_files:
            raise FileNotFoundError(f"No video file found in {project_dir}")

        raw_input = str(video_files[0])
        run = PipelineRun(project_dir=project_dir)

        messages: list[dict[str, Any]] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"Process the video project at: {project_dir}\nRaw input file: {raw_input}",
            },
        ]

        # Agentic tool-use loop
        max_iterations = 20
        for iteration in range(max_iterations):
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=messages,
                tools=TOOLS,
                tool_choice="auto",
            )

            msg = response.choices[0].message
            messages.append(msg.model_dump())

            if not msg.tool_calls:
                # Agent finished or is waiting for human
                logger.info(f"Agent message: {msg.content}")
                if "suggest_cuts" in run.outputs and run.approved_cuts is None:
                    # HITL gate: get cut approvals
                    suggestions_path = run.outputs["suggest_cuts"].get("suggestions_path")
                    if suggestions_path:
                        cuts = json.loads(Path(suggestions_path).read_text())
                        if human_review_fn:
                            run.approved_cuts = human_review_fn(cuts)
                        else:
                            run.approved_cuts = _default_hitl(cuts)
                        # Inject approved cuts back into conversation
                        messages.append({
                            "role": "user",
                            "content": (
                                f"Human approved cuts. Apply these keep_segments: "
                                f"{json.dumps(run.approved_cuts)}"
                            ),
                        })
                        continue
                break

            # Dispatch tool calls
            for tc in msg.tool_calls:
                name = tc.function.name
                args = json.loads(tc.function.arguments)
                logger.info(f"[Pipeline] Calling tool: {name} args={args}")

                try:
                    result = TOOL_DISPATCH[name](**args)
                    run.outputs[name] = result
                    logger.info(f"[Pipeline] {name} ✓ → {result}")
                    tool_result = json.dumps(result)
                except Exception as exc:
                    logger.error(f"[Pipeline] {name} FAILED: {exc}")
                    run.failed_at = name
                    tool_result = json.dumps({"error": str(exc), "checkpoint_halted": True})

                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": tool_result,
                })

                if run.failed_at:
                    break

            if run.failed_at:
                break

        if not run.failed_at and "render" in run.outputs:
            run.complete = True

        return run


def _default_hitl(cuts: list[dict[str, Any]]) -> list[dict[str, float]]:
    """CLI HITL: print suggestions and let user approve/reject."""
    print("\n=== CUT SUGGESTIONS (HITL Review) ===")
    for i, cut in enumerate(cuts):
        print(f"  [{i}] {cut['type']:8s}  {cut['start']:.2f}s → {cut['end']:.2f}s  {cut.get('word', '')}")

    approved_indices = input("\nEnter comma-separated indices to REMOVE (or press Enter to skip all): ").strip()
    if not approved_indices:
        return []

    remove_set = set(int(x) for x in approved_indices.split(",") if x.strip().isdigit())
    # Build keep_segments from gaps around removed cuts
    # Simplified: return all non-removed segments as keep
    return [{"start": 0.0, "end": 1e9}]  # Real impl: build proper keep list
