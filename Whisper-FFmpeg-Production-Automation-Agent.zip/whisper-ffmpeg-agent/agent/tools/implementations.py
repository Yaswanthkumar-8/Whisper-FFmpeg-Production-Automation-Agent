"""
Concrete implementations of each production tool.
Each function maps 1:1 to an entry in TOOLS and is called by the dispatcher.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

WHISPER_MODEL = os.getenv("WHISPER_MODEL", "large-v3")


# ---------------------------------------------------------------------------
# transcribe
# ---------------------------------------------------------------------------

def transcribe(input_path: str, language: str | None = None) -> dict[str, Any]:
    """Run Whisper on input_path, return word-level transcript dict."""
    try:
        import whisper  # type: ignore
    except ImportError:
        raise RuntimeError("openai-whisper not installed. Run: pip install openai-whisper")

    model = whisper.load_model(WHISPER_MODEL)
    result = model.transcribe(
        input_path,
        language=language,
        word_timestamps=True,
        verbose=False,
    )

    transcript_path = Path(input_path).with_suffix(".json")
    transcript_path.write_text(json.dumps(result, indent=2))

    srt_path = Path(input_path).with_suffix(".srt")
    _write_srt(result["segments"], str(srt_path))

    return {
        "transcript_path": str(transcript_path),
        "srt_path": str(srt_path),
        "language": result.get("language"),
        "segment_count": len(result["segments"]),
        "duration_s": result["segments"][-1]["end"] if result["segments"] else 0,
    }


# ---------------------------------------------------------------------------
# suggest_cuts
# ---------------------------------------------------------------------------

DEFAULT_FILLERS = ["um", "uh", "like", "you know", "basically", "literally", "actually"]


def suggest_cuts(
    transcript_path: str,
    filler_words: list[str] | None = None,
    silence_threshold_ms: int = 1000,
) -> dict[str, Any]:
    """Identify filler words and silences. Returns suggestions for HITL review."""
    fillers = set(w.lower() for w in (filler_words or DEFAULT_FILLERS))
    data = json.loads(Path(transcript_path).read_text())
    segments = data.get("segments", [])

    filler_cuts: list[dict[str, Any]] = []
    silence_cuts: list[dict[str, Any]] = []

    for seg in segments:
        words = seg.get("words", [])
        for word in words:
            if word.get("word", "").strip().lower() in fillers:
                filler_cuts.append({
                    "start": word["start"],
                    "end": word["end"],
                    "word": word["word"].strip(),
                    "type": "filler",
                })

    # Detect silences between segments
    for i in range(1, len(segments)):
        gap = segments[i]["start"] - segments[i - 1]["end"]
        if gap * 1000 >= silence_threshold_ms:
            silence_cuts.append({
                "start": segments[i - 1]["end"],
                "end": segments[i]["start"],
                "duration_ms": int(gap * 1000),
                "type": "silence",
            })

    suggestions = filler_cuts + silence_cuts
    suggestions.sort(key=lambda x: x["start"])

    output_path = Path(transcript_path).with_name("cut_suggestions.json")
    output_path.write_text(json.dumps(suggestions, indent=2))

    return {
        "suggestions_path": str(output_path),
        "filler_count": len(filler_cuts),
        "silence_count": len(silence_cuts),
        "total_suggestions": len(suggestions),
        "review_required": True,
    }


# ---------------------------------------------------------------------------
# apply_cuts
# ---------------------------------------------------------------------------

def apply_cuts(
    input_path: str,
    output_path: str,
    keep_segments: list[dict[str, float]],
) -> dict[str, Any]:
    """Apply HITL-approved cuts via FFmpeg concat demuxer."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        concat_list = f.name
        for seg in keep_segments:
            f.write(f"file '{os.path.abspath(input_path)}'\n")
            f.write(f"inpoint {seg['start']}\n")
            f.write(f"outpoint {seg['end']}\n")

    cmd = [
        "ffmpeg", "-y",
        "-f", "concat", "-safe", "0",
        "-i", concat_list,
        "-c", "copy",
        output_path,
    ]
    _run_ffmpeg(cmd)
    return {"output_path": output_path, "segments_applied": len(keep_segments)}


# ---------------------------------------------------------------------------
# burn_captions
# ---------------------------------------------------------------------------

def burn_captions(
    input_path: str,
    captions_path: str,
    output_path: str,
    font_size: int = 28,
) -> dict[str, Any]:
    cmd = [
        "ffmpeg", "-y",
        "-i", input_path,
        "-vf", f"subtitles={captions_path}:force_style='FontSize={font_size},PrimaryColour=&HFFFFFF'",
        "-c:a", "copy",
        output_path,
    ]
    _run_ffmpeg(cmd)
    return {"output_path": output_path}


# ---------------------------------------------------------------------------
# color_grade
# ---------------------------------------------------------------------------

PRESETS: dict[str, str] = {
    "neutral": "colorbalance=rs=0:gs=0:bs=0",
    "warm": "colorbalance=rs=0.1:gs=0.02:bs=-0.1",
    "cool": "colorbalance=rs=-0.1:gs=0.02:bs=0.1",
    "cinematic": "curves=r='0/0 0.25/0.2 0.75/0.8 1/1':g='0/0 0.25/0.22 0.75/0.78 1/1':b='0/0 0.25/0.25 0.75/0.75 1/0.95'",
}


def color_grade(
    input_path: str,
    output_path: str,
    lut_path: str | None = None,
    preset: str = "neutral",
) -> dict[str, Any]:
    if lut_path:
        vf = f"lut3d={lut_path}"
    else:
        vf = PRESETS.get(preset, PRESETS["neutral"])

    cmd = [
        "ffmpeg", "-y",
        "-i", input_path,
        "-vf", vf,
        "-c:a", "copy",
        output_path,
    ]
    _run_ffmpeg(cmd)
    return {"output_path": output_path, "grade_applied": lut_path or preset}


# ---------------------------------------------------------------------------
# render
# ---------------------------------------------------------------------------

CODEC_MAP = {"h264": "libx264", "h265": "libx265", "vp9": "libvpx-vp9"}


def render(
    input_path: str,
    output_path: str,
    codec: str = "h264",
    crf: int = 23,
    audio_bitrate: str = "192k",
) -> dict[str, Any]:
    encoder = CODEC_MAP.get(codec, "libx264")
    cmd = [
        "ffmpeg", "-y",
        "-i", input_path,
        "-c:v", encoder,
        "-crf", str(crf),
        "-preset", "slow",
        "-c:a", "aac",
        "-b:a", audio_bitrate,
        output_path,
    ]
    _run_ffmpeg(cmd)
    size_mb = Path(output_path).stat().st_size / 1_000_000
    return {"output_path": output_path, "size_mb": round(size_mb, 2)}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _run_ffmpeg(cmd: list[str]) -> None:
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg error:\n{result.stderr[-2000:]}")


def _write_srt(segments: list[dict[str, Any]], path: str) -> None:
    lines: list[str] = []
    for i, seg in enumerate(segments, 1):
        start = _fmt_ts(seg["start"])
        end = _fmt_ts(seg["end"])
        lines.append(f"{i}\n{start} --> {end}\n{seg['text'].strip()}\n")
    Path(path).write_text("\n".join(lines))


def _fmt_ts(s: float) -> str:
    h = int(s // 3600)
    m = int((s % 3600) // 60)
    sec = s % 60
    return f"{h:02d}:{m:02d}:{sec:06.3f}".replace(".", ",")
