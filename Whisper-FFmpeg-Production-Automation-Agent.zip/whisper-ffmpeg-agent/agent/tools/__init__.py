"""
Whisper + FFmpeg Production Automation Agent
Each production step is a callable tool the planner can chain.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import openai

logger = logging.getLogger(__name__)

WHISPER_MODEL = os.getenv("WHISPER_MODEL", "large-v3")

# ---------------------------------------------------------------------------
# Tool definitions (fed to the OpenAI tool-use API)
# ---------------------------------------------------------------------------

TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "transcribe",
            "description": "Transcribe a video/audio file using Whisper. Returns word-level timestamps.",
            "parameters": {
                "type": "object",
                "properties": {
                    "input_path": {"type": "string", "description": "Path to input media file"},
                    "language": {"type": "string", "description": "ISO language code (optional)"},
                },
                "required": ["input_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "suggest_cuts",
            "description": "Analyse transcript for filler words and silences. Returns cut suggestions for HITL review.",
            "parameters": {
                "type": "object",
                "properties": {
                    "transcript_path": {"type": "string"},
                    "filler_words": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Custom filler word list",
                    },
                    "silence_threshold_ms": {"type": "integer", "description": "Min silence to flag (ms)"},
                },
                "required": ["transcript_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "burn_captions",
            "description": "Burn SRT/VTT captions into the video using FFmpeg.",
            "parameters": {
                "type": "object",
                "properties": {
                    "input_path": {"type": "string"},
                    "captions_path": {"type": "string"},
                    "output_path": {"type": "string"},
                    "font_size": {"type": "integer", "default": 28},
                },
                "required": ["input_path", "captions_path", "output_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "color_grade",
            "description": "Apply a colour LUT or ffmpeg colorbalance/curves filter.",
            "parameters": {
                "type": "object",
                "properties": {
                    "input_path": {"type": "string"},
                    "output_path": {"type": "string"},
                    "lut_path": {"type": "string", "description": ".cube LUT file (optional)"},
                    "preset": {
                        "type": "string",
                        "enum": ["neutral", "warm", "cool", "cinematic"],
                        "description": "Built-in preset if no LUT provided",
                    },
                },
                "required": ["input_path", "output_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "render",
            "description": "Final render: encode to target codec and container.",
            "parameters": {
                "type": "object",
                "properties": {
                    "input_path": {"type": "string"},
                    "output_path": {"type": "string"},
                    "codec": {"type": "string", "enum": ["h264", "h265", "vp9"], "default": "h264"},
                    "crf": {"type": "integer", "description": "Constant Rate Factor (18–28)", "default": 23},
                    "audio_bitrate": {"type": "string", "default": "192k"},
                },
                "required": ["input_path", "output_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "apply_cuts",
            "description": "Apply approved cuts to video using FFmpeg concat demuxer.",
            "parameters": {
                "type": "object",
                "properties": {
                    "input_path": {"type": "string"},
                    "output_path": {"type": "string"},
                    "keep_segments": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "start": {"type": "number"},
                                "end": {"type": "number"},
                            },
                        },
                        "description": "List of time segments to KEEP (seconds)",
                    },
                },
                "required": ["input_path", "output_path", "keep_segments"],
            },
        },
    },
]
